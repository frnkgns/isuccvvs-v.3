-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2024 at 02:28 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `isucc`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `studentid` varchar(100) NOT NULL,
  `NoofVotes` int(11) NOT NULL,
  `organization` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `college` varchar(100) NOT NULL,
  `course` varchar(100) NOT NULL,
  `quotes` varchar(1000) NOT NULL,
  `profile` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`studentid`, `NoofVotes`, `organization`, `position`, `name`, `college`, `course`, `quotes`, `profile`) VALUES
('t', 2, 'SSC', 'PRESIDENT', ';nw;jkrnekr', 'CBM', 'BSBA', 'poi', '441941566_1156784375652346_368895775735785229_n.jpg'),
('12345', 7, 'SSC', 'PRESIDENT', 'Wag Ako', 'CCJE', 'BSCrim', ';fjwlejbweljrb', 'jobs.jpg'),
('sal et', 1, 'SSC', 'VICE-PRESIDENT', 'Hatdog', 'CCSICT', 'BSEMC', 'poi', 'brid.png'),
('ibang ano naman', 0, 'SBO', 'COUNCILOR', 'entelrjtn', 'CBM', 'BSAIS', ';fjwlejbweljrb', 'K-CHC.jpg'),
('ASD', 0, 'SBO', 'SBOCOUNCILOR', 'WEWE', 'CED', 'BEED', ';fjwlejbweljrb', 'Colorful Pastel Cute Aesthetic A Day In My Life YouTube Thumbnail.png'),
(' YUYU', 0, 'SBO', 'SBO3RDYEARREPRESENTATIVE', 'FGFG', 'CCJE', 'BSCrim', 'poi', 'Brown & White Aesthetic Happy Birthday Instagram Post.png'),
('ced2', 1, 'SBO', 'SBOPRESIDENT', 'ced2', 'CED', 'BEED', 'ced', 'Colorful Pastel Cute Aesthetic A Day In My Life YouTube Thumbnail.png'),
('ced1', 1, 'SBO', 'SBOVICE-PRESIDENT', 'ced1', 'CED', 'BEED', 'ced1', '08b93afc-6f2e-4c8f-b406-161a3a3b74ea.jpg'),
('ced3', 1, 'SBO', 'SBOSECRETARY', 'ced', 'CED', 'BEED', 'ced', 'Lilac Minimalist Travel Destination Instagram Story.png'),
('ced4', 0, 'SBO', 'SBOTREASURER', 'ced4', 'CED', 'BSE', 'ced4', 'Lilac Minimalist Travel Destination Instagram Story.png'),
('ced5', 1, 'SBO', 'SBOAUDITOR', 'ced5', 'CED', 'BEED', 'ced', 'Lilac Minimalist Travel Destination Instagram Story.png'),
('ced6', 1, 'SBO', 'SBOACCOUNTANT', 'ced6', 'CED', 'BEED', 'ced6', 'Lilac Minimalist Travel Destination Instagram Story.png'),
('ced7', 0, 'SBO', 'SBOPIO', 'ced7', 'CED', 'BEED', 'ced7', 'Lilac Minimalist Travel Destination Instagram Story.png'),
('ced8', 1, 'SBO', 'SBOBUSINESSMANAGERI', 'ced8', 'CED', 'BEED', 'ced8', 'Lilac Minimalist Travel Destination Instagram Story.png'),
('ced9', 1, 'SBO', 'SBOBUSINESSMANAGERII', 'ced9', 'CED', 'BEED', 'ced9', 'Lilac Minimalist Travel Destination Instagram Story.png'),
('ced10', 1, 'SBO', 'SBO1STYEARREPRESENTATIVE', 'ced10', 'CED', 'BEED', 'ced10', 'Lilac Minimalist Travel Destination Instagram Story.png'),
('ced11', 1, 'SBO', 'SBO2NDYEARREPRESENTATIVE', 'ced11', 'CED', 'BSE', 'ced11', 'Lilac Minimalist Travel Destination Instagram Story.png'),
('ced12', 1, 'SBO', 'SBO3RDYEARREPRESENTATIVE', 'ced12', 'CED', 'BEED', 'ced12', 'Lilac Minimalist Travel Destination Instagram Story.png'),
('ced13', 1, 'SBO', 'SBO4THYEARREPRESENTATIVE', 'ced13', 'CED', 'BEED', 'ced13', 'Lilac Minimalist Travel Destination Instagram Story.png'),
('09', 0, 'SBO', 'SBOCOUNCILOR', 'qwe', 'CBM', 'BSBA', 'qweasdasd', 'cocola texture.jpg'),
('098', 0, 'SSC', 'ACCOUNTANT', '123', 'CBM', 'BSBA', 'asdasdasdasd', 'graph1.jpg'),
('13', 0, 'SSC', 'TREASURER', '13', 'CBM', 'BSBA', 'o;uhf;uhfwef', '422810236_359074293589483_1939743956422571658_n.jpg'),
('14', 0, 'SSC', 'AUDITOR', '14', 'CBM', 'BSTM', 'sdasdasd', 'graph2.png'),
('15', 0, 'SSC', 'SECRETARY', 'qwe', 'CBM', 'BSHM', 'asdasdaflfgkjsfnsdf', 'hospitanicon.png');

-- --------------------------------------------------------

--
-- Table structure for table `logincode`
--

CREATE TABLE `logincode` (
  `code` text NOT NULL,
  `college` text NOT NULL,
  `Voted` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logincode`
--

INSERT INTO `logincode` (`code`, `college`, `Voted`) VALUES
('sas1', 'sas', 'yes'),
('ccsict1', 'ccsict', ''),
('ps1', 'ps', ''),
('iat1', 'iat', ''),
('crim1', 'crim', ''),
('ced1', 'ced', ''),
('cbm1', 'cbm', ''),
('sas1', 'sas', 'yes'),
('ccsict1', 'ccsict', ''),
('ps1', 'ps', ''),
('iat1', 'iat', ''),
('crim1', 'crim', ''),
('ced1', 'ced', ''),
('cbm1', 'cbm', ''),
('123', 'admin', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
